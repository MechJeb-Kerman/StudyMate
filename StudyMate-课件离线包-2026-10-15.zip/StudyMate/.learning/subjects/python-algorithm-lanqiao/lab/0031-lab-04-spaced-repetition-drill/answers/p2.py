# p2 · 四边形合并
#
# 在这里写你的答案：读标准输入、写标准输出，**不要** import 参考解。
#
# 本题：60 分 ｜ 时限 25 秒 ｜ 预计用 70 分钟
#   输入格式与数据范围见 ../problems/p2/statement.md
#   写好之后用 py score.py 跑分（它会拿 ../problems/p2/cases 里的数据判）
#
# 提示：先把「读入 + 暴力解」跑通，再换正解。留一份能跑的东西在手边，
#       胜过一份写到一半的正解。
import sys


def main():
    data = sys.stdin.buffer.read().split()
    # 待填：把 data 变成答案，写进 sys.stdout
    return


main()
